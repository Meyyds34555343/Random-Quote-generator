# 💡 Random Quote Generator

A simple **Random Quote Generator** built with **Python Tkinter**.  
It displays  quotes randomly and allows users to copy the quote to the clipboard.

---

##  Features

- Click **Show Quote** to display a random quote.  
- Click **Copy Quote** to copy the currently displayed quote to the clipboard.  
- Clean and simple GUI interface with readable fonts.  



